package com.capgemin.dcs.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="distance_calculator")
public class user implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int distanceId;
	private String source;
	private String destination;
	private int distanceInKm;
	private double distanceInMiles;
	@Override
	public String toString() {
		return "user [distanceId=" + distanceId + ", source=" + source
				+ ", destination=" + destination + ", distanceInKm="
				+ distanceInKm + ", distanceInMiles=" + distanceInMiles + "]";
	}
	public user() {
		super();
		// TODO Auto-generated constructor stub
	}
	public user(int distanceId, String source, String destination,
			int distanceInKm, double distanceInMiles) {
		super();
		this.distanceId = distanceId;
		this.source = source;
		this.destination = destination;
		this.distanceInKm = distanceInKm;
		this.distanceInMiles = distanceInMiles;
	}
	public int getDistanceId() {
		return distanceId;
	}
	public void setDistanceId(int distanceId) {
		this.distanceId = distanceId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getDistanceInKm() {
		return distanceInKm;
	}
	public void setDistanceInKm(int distanceInKm) {
		this.distanceInKm = distanceInKm;
	}
	public double getDistanceInMiles() {
		return distanceInMiles;
	}
	public void setDistanceInMiles(double distanceInMiles) {
		this.distanceInMiles = distanceInMiles;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}